export default function MessagePage() {

    return(
        <>
            <h1> Page des messages </h1>
        </>
    )
}