export interface Author {
    firstname: string;
    lastname: string;
}
