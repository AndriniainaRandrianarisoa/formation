const fakePost = [
  {
    id: 1,
    title: "title 1",
    body: "body1",
    userId: {
      id: 1,
      firstname: "afas", 
      lastname: "dsafwasf"
    }
  },
  {
    id: 2,
    title: "title 1",
    body: "body1",
    userId: 1
  },
  {
    id: 3,
    title: "title 1",
    body: "body1",
    userId: 1
  },
  {
    id: 4,
    title: "title 1",
    body: "body1",
    userId: 1
  },

]

const fakePost1 = [
  {
    id: 1,
    title: "title 1",
    body: "body1",
    userId: {
      id: 1,
      firstname: "afas", 
      lastname: "dsafwasf"
    }
  },
  {
    id: 2,
    title: "title 1",
    body: "body1",
    userId: 1
  },
  {
    id: 3,
    title: "title 1",
    body: "body1",
    userId: 1
  },
  {
    id: 4,
    title: "title 1",
    body: "body1",
    userId: 1
  },

]



const PostData = {
  datas : fakePost
}


const PostData1mu7  = {
  datas : fakePost
}

export default { PostData }