const friends = [
  "mimi", 
  "dylan", 
  "marie"
]

const user_miaina = {
  friends : [
    "dylan", 
    "fitia"
  ], 
  user : {
    id: "5667", 
    lastname: "miaina",
    firstname: "Raharilisy"
  }, 
  comments : [
    {
      id: 1, 
      date: "5/01/2011"
    },
    {
      id: 2, 
      date: "5/01/2011"
    },
    {
      id: 3, 
      date: "5/01/2011"
    },
    {
      id: 4, 
      date: "5/01/2011"
    }
  ],
  pictures: [
    {
      date: "5/01/2011",
      media: ""
    },
    {
      date: "5/01/2011",
      media: ""
    }
  ],
}

console.log("coucou", user_miaina.user.firstname, user_miaina.user.lastname)

