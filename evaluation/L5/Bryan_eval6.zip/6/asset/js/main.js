const firstName = document.querySelector("#firstName");
const lastName = document.querySelector("#lastName");
const title = document.querySelector("#title");
const description= document.querySelector("#description");
const image = document.querySelector("#image");
const urText = document.querySelector("#urText");
const datePublish = document.querySelector("#datePublish");
const recup = document.querySelector("#stp");
recup.addEventListener("click", megaFunction);
const categoryList = document.querySelector("#categoryList");
const categoryChose = document.querySelector("#categoryChose");
const leadership = document.querySelector("#leadership");
leadership.addEventListener("click", leadFunction);
const management = document.querySelector("#Management");
management.addEventListener("click", managementFunction);
const product = document.querySelector("#Product");
product.addEventListener("click", productFunction);
const research = document.querySelector("#Research");
research.addEventListener("click", researchFunction);
const frameworks = document.querySelector("#Frameworks");
frameworks.addEventListener("click", frameworksFunction);
const design = document.querySelector("#design");
design.addEventListener("click", designFunction);
const software_development = document.querySelector("#software-development");
software_development.addEventListener("click", softdevelopmentFunction);
const tools = document.querySelector("#tools");
tools.addEventListener("click", toolsFunction);
const saaS = document.querySelector("#SaaS");
saaS.addEventListener("click", saaSFunction);
const customer_Success = document.querySelector("#customer-Success");
customer_Success.addEventListener("click", custSuccessFunction);
const interface = document.querySelector("#Interface");
interface.addEventListener("click", interfaceFunction);
const presentation = document.querySelector("#presentation");
presentation.addEventListener("click", presentationFunction);
const podcast = document.querySelector("#Podcast");
podcast.addEventListener("click", podcastFunction);
const deleteAll = document.querySelector("#delete-all");
deleteAll.addEventListener("click", deleteFunction)


function leadFunction(){
    categoryChose.append(leadership);
}
function managementFunction(){
    categoryChose.append(management);
}
function productFunction(){
    categoryChose.append(product);
}
function researchFunction(){
    categoryChose.append(research);
}
function frameworksFunction(){
    categoryChose.append(frameworks);
}
function softdevelopmentFunction(){
    categoryChose.append(software_development);
}
function toolsFunction(){
    categoryChose.append(tools);
}
function saaSFunction(){
    categoryChose.append(saaS);
}
function custSuccessFunction(){
    categoryChose.append(customer_Success);
}
function interfaceFunction(){
    categoryChose.append(interface);
}
function presentationFunction(){
    categoryChose.append(presentation);
}
function designFunction(){
    categoryChose.append(design);
}

function podcastFunction(){
    categoryChose.append(podcast);

}

function deleteFunction(){
    categoryList.append(categoryChose);
}






function megaFunction(data){
    var data = [];

let objet = {
    name: firstName.value,
    lastName : lastName.value,
    title : title.id,
    category : categoryChose?.li?.value,
    description : description.value,
    image : image.value,
    text: urText.value,
    datePublish: datePublish.value,
} 
console.log(objet, "cc")
data.push(objet)
console.log(data)
return data
}

console.log(megaFunction(data = []), 'eazeaea')





