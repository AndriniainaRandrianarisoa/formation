<?php
$connexion_bdd = new PDO('mysql:host=mysql;dbname=test', 'user', 'pass');

if (!empty($_POST)) {
    $imgCount = count(glob('assets/img/*png'));
    $imgName = "Image". $imgCount+1 . ".png";
    move_uploaded_file($_FILES['picture']['tmp_name'],"assets/img/".$imgName);
    $data = [
        'author' => $_POST['name'],
        'tags' => $_POST['tags'],
        'title' => $_POST['title'],
        'article' => $_POST['article'],
        'img' => $imgName
    ];
    $sql = $connexion_bdd->prepare("INSERT INTO blog (author,tags,title,article,img,created) VALUES (:author,:tags,:title,:article,:img,NOW())");
    if ($sql->execute($data)) {
        header('Location:index.html');
    }
}
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/rules.css" />
    <link rel="stylesheet" href="assets/css/font.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <title>The Blog - Add Post</title>
</head>

<body>
    <div id="page" class="cFlex aI-C">
        <header class="cFlex">
            <nav class="rFlex jC-SB">
                <p>The Blog</p>
                <div class="rFlex jC-FE">
                    <a href="index.html">Blog</a>
                    <a href="post.php">Add Post</a>
                    <a href="about.html">About</a>
                    <a href="newsletter.html">Newletter</a>
                </div>
            </nav>
            <h2>Add a new post</h2>
        </header>
        <main class="cFlex">
            <form method="POST" class="cFlex g24" enctype="multipart/form-data">
                <div class="rFlex jC-SB g12">
                    <label for="name">Author's name :</label>
                    <input id="name" name="name" type="text" required>
                </div>
                <div class="rFlex jC-SB g12">
                    <label for="title">Title :</label>
                    <input id="title" name="title" type="text" required>
                </div>
                <div class="rFlex jC-SB g12">
                    <label for="tag">Tag :</label>
                    <div class="cFlex g8">
                        <div id="listTag" class="cFlex"></div>
                        <select name="tag" id="tag">
                            <option value="" selected>--Please choose a tag--</option>
                            <option value="design">design</option>
                            <option value="research">research</option>
                            <option value="podcast">podcast</option>
                            <option value="presentation">presentation</option>
                            <option value="tools">tools</option>
                            <option value="interface">interface</option>
                            <option value="leardership">leardership</option>
                            <option value="management">management</option>
                            <option value="customersuccess">customer success</option>
                            <option value="product">product</option>
                            <option value="framework">framework</option>
                            <option value="saas">saas</option>
                        </select>
                        <input style="display: none;" name="tags" id="tags" type="text">
                    </div>
                </div>
                <div class="rFlex jC-SB g12">
                    <label for="picture">Illustration picture :</label>
                    <input id="picture" name="picture" type="file" accept="image/png">
                </div>
                <div class="cFlex g12">
                    <label for="article">Article :</label>
                    <textarea id="article" name="article" rows="50" cols="50"></textarea>
                </div>
                <input type="submit">
            </form>
        </main>
        <footer class="rFlex g14 jC-FS">
            <a>© 2023</a>
            <a>Twitter</a>
            <a>LinkedIn</a>
            <a>Email</a>
            <a>RSS feed</a>
            <a>Add to Feedly</a>
        </footer>
    </div>
</body>
<script>
    let listTag = document.getElementById('listTag');
    let select = document.querySelector('select');
    let sentTags = document.querySelector('#tags')
    select.addEventListener('change', selectTag);
    console.log(select)
    console.log(listTag)
    sentTags.value=""
    function selectTag() {
        switch (listTag.childElementCount) {
            case 2:
            case 1:
                for (let span of listTag.querySelectorAll('span')) {
                    if (span.textContent == select.value) {
                        select.value = ""
                        return
                    }
                }
            case 0:
                let divA = document.createElement('div');
                divA.innerHTML = `  <button class="rFlex aI-C">
                                    <img src="assets/img/deletebutton_87299.png" width="24" height="24">
                                </button>
                                <span>${select.value}</span>`;
                divA.classList.add("rFlex", "g8", "aI-C")
                listTag.appendChild(divA)
                divA.querySelector('button').addEventListener('click', deleteTag);
                if (listTag.childElementCount == 3) {
                    select[0].innerHTML = "--Can't choose more than 3--"
                    select.setAttribute('disabled', "")
                }
                if (sentTags.value == ""){
                    sentTags.value = select.value
                } else {
                    sentTags.value += ","+select.value;
                }
                select.value = ""
                break;
        }
    }

    function deleteTag(event) {
        let array = sentTags.value.split(',');
        let tagDiv = event.target.parentNode.parentNode;
        let tag = tagDiv.querySelector("span");

        for (let i in array) {
            array[i].trim()
            if (array[i] == tag.textContent || array[i]=="") {
                array.splice(i,1)
            } else {
            }
        }
        sentTags.value = array.toString()
        tagDiv.remove()
        if (select.hasAttribute('disabled', "")) {
            select.removeAttribute('disabled', "")
            select[0].innerHTML = "--Please choose a tag--"
        }
    }
</script>

</html>