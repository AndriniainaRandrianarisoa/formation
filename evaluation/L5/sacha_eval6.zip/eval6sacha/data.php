<?php

$db = new PDO('mysql:host=mysql;dbname=test', 'user', 'pass');

$query = $db->query('SELECT * FROM blog');

header('Content-Type: application/json; charset=utf-8');
$data = file_get_contents('php://input');
$json = json_decode($data, true);

echo json_encode($query->fetchAll(PDO::FETCH_ASSOC));
?>