let divAllPost = document.querySelector('#allPosts')
const monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Agu', 'Sep', 'Oct', 'Nov', 'Dec']

async function fetchArticles() {
    try {
        const response = await fetch("http://localhost:8083/data.php");
        const jsonData = await response.json();
        let i = 0
        for (let article of jsonData) {
            i++;
            if (i <= 6) {
                let blogDiv = document.createElement("div");
                let tagsArray = article.tags.split(',');
                let dateArray = article.created.split('-');
                let day = dateArray[2];
                let month = monthArray[(parseInt(dateArray[1])-1)];
                let year = dateArray[0];
                let text = article.article;
                if ((text.length)>90){
                    text= text.substring(0,88)+"...";
                }
                blogDiv.innerHTML = `<img src="assets/img/${article.img}"><div class="cFlex g24"><div class="cFlex g12 "><h5 class="autorAndDate">${article.author} • ${day} ${month} ${year}</h5><div class="blogTitle rFlex g16 aI-FS jC-SB"><h3>${article.title}</h3><img src="assets/img/Iconwrap.svg"></div><p>${text}</p></div><div id="category" class="rFlex g8"></div>`;
                
                let listTags = blogDiv.querySelector('#category')
                for (let tag of tagsArray) {
                    let div = document.createElement("div");
                    div.classList.add("tag", tag);
                    div.innerHTML = tag;
                    listTags.append(div);
                }
                blogDiv.classList.add('vNormalPost', 'g32', 'cFlex', 'aI-FS')
                divAllPost.append(blogDiv)
            }
        }
    } catch (error) {
        console.log("erreur");
    }
}

fetchArticles();