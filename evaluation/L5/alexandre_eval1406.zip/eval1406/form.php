<?php
$db = new PDO('mysql:host=mysql;dbname=test', 'user', 'pass');

$title = $_POST['title'];
$author = $_POST['author'];
$date = $_POST['date'];
$image = $_FILES['image']['name'];
$content = $_POST['content'];

try {
    $query = "INSERT INTO posts (title, author, date, image, content) VALUES (?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->execute([$title, $author, $date, $image, $content]);

    echo "Données enregistrées";

} catch (e) {
    echo "Erreur : ";
}
?>
