export default function HomePage() {

    return (
        <> 
            <h1> Home Page </h1>
            <p> Ceci est la page d'accueil </p>
        </>
    )
}