export interface Message {
    title: string;
    category: string;
    message: string;
}
