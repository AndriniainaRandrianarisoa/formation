export interface Message {
    title: number;
    category: string;
    message: string;
}
