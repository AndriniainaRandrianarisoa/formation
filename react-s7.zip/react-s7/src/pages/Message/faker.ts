const messagesFaker = [{
  id: 1,
  title: "titre test 1", 
  message: "content 1"
}, 
{
  id: 2,
  title: "titre test 2", 
  message: "content 2"
}, 
{
  id: 3,
  title: "titre test 3", 
  message: "content 3"
}, 
{
  id: 4,
  title: "titre test 4", 
  message: "content 4"
}]

export {messagesFaker}