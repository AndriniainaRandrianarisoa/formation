const products = [
  {
      id: 1,
      name: "Laptop Pro",
      price: 1299.99,
      stock: 5,
      category: "Electronics"
  },
  {
      id: 2,
      name: "Casque Sans Fil",
      price: 199.99,
      stock: 15,
      category: "Audio"
  },
  {
      id: 3,
      name: "Souris Gaming",
      price: 79.99,
      stock: 2,
      category: "Accessories"
  },
  {
      id: 4,
      name: "Clavier Mécanique",
      price: 159.99,
      stock: 8,
      category: "Accessories"
  }
];