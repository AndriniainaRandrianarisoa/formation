import './HomePage.css';

export default function HomePage() {

    return(
        <>  
            <h1> Page d'accueil </h1>

        </>
    )
}