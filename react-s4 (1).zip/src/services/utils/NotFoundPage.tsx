export default function NotFoundPage() { 

    return (
        <>
            <h1> 404 ERROR NOT FOUND PAGE </h1>
        </>
    )
}